from kyt import *

# Import modul-modul yang diperlukan
import subprocess
import time
import random
import requests
import datetime as DT
import asyncio
from telethon.tl.custom import Button
from telethon import events

# (Pastikan variabel DOMAIN, HOST, PUB, dan fungsi valid() 
# sudah ada di file 'kyt.py' atau didefinisikan di atas kode ini)


# =================================================================
# 1. CREATE SSH (DENGAN LIMIT IP)
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		try:
			# --- [PERBAIKAN] Menggunakan loop 'while' untuk validasi sender.id ---
			async with bot.conversation(chat, timeout=120) as user_convo:
				await event.respond('**Username:**')
				while True:
					user_event = await user_convo.wait_event(events.NewMessage(incoming=True))
					if user_event.sender_id == sender.id:
						user = user_event.raw_text
						break # Keluar loop jika user benar
					# Jika bukan user yg benar, loop akan menunggu pesan baru lagi
			
			async with bot.conversation(chat, timeout=120) as pw_convo:
				await event.respond("**Password:**")
				while True:
					pw_event = await pw_convo.wait_event(events.NewMessage(incoming=True))
					if pw_event.sender_id == sender.id:
						pw = pw_event.raw_text
						break
	
			async with bot.conversation(chat, timeout=120) as limit_convo:
				await event.respond("**Input Max Login/IP Limit:**\n`Contoh: 2`")
				while True:
					limit_event = await limit_convo.wait_event(events.NewMessage(incoming=True))
					if limit_event.sender_id == sender.id:
						limit = limit_event.raw_text
						break
	
			# Validasi input limit (harus angka)
			try:
				int(limit)
			except ValueError:
				await event.respond("**Error: Input limit harus berupa angka.**\nSilakan ulangi proses.")
				return 
				
			async with bot.conversation(chat, timeout=120) as exp_convo:
				await event.respond("**Choose Expiry Day**",buttons=[
					[Button.inline(" 3 Day ","3"), Button.inline(" 7 Day ","7")],
					[Button.inline(" 30 Day ","30"), Button.inline(" 60 Day ","60")]
				])
				while True:
					exp_event = await exp_convo.wait_event(events.CallbackQuery())
					if exp_event.sender_id == sender.id:
						exp = exp_event.data.decode("ascii")
						try:
							await exp_event.delete()
						except:
							pass
						break # Keluar loop
		
			await event.edit("Processing.")
			# ... (animasi loading) ...
			await event.edit("`Wait.. Setting up an Account`")
	
			cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user} && echo "{user} hard maxlogins {limit}" >> /etc/security/limits.conf'
	
			try:
				subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
			except subprocess.CalledProcessError:
				await event.respond("**User Already Exist**")
			else:
				today = DT.date.today()
				later = today + DT.timedelta(days=int(exp))
	
				msg = f"""
**━━━━━━━━━━━━━━━━━**
**🟢 SSH ACCOUNT 🟢**
**━━━━━━━━━━━━━━━━━**
**» Username      :** `{user.strip()}`
**» Password      :** `{pw.strip()}`
**» Max Login/IP  :** `{limit.strip()}`
**━━━━━━━━━━━━━━━━━**
**» Host          :** `{DOMAIN}`
**» Host Slowdns  :** `{HOST}`
**» Pub Key       :** `{PUB}`
**» Port OpenSSH  :** `443, 80, 22`
**» Port DNS      :** `443, 53 ,22`
**» Port Dropbear :** `443, 109`
**» Port Dropbear WS :** `443, 109`
**» Port SSH WS     :** `80, 8080, 8081-9999 `
**» Port SSH SSL WS :** `443`
**» Port SSL/TLS    :** `222-1000`
**» Port OVPN WS SSL :** `443`
**» Port OVPN SSL   :** `443`
**» Port OVPN TCP   :** `443, 1194`
**» Port OVPN UDP   :** `2200`
**» Proxy Squid     :** `3128`
**» BadVPN UDP      :** `7100, 7300, 7300`
**━━━━━━━━━━━━━━━━━**
**» Payload WSS     :** `GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━**
**» OpenVPN WS SSL  :** `https://{DOMAIN}:81/ws-ssl.ovpn`
**» OpenVPN SSL     :** `https://{DOMAIN}:81/ssl.ovpn`
**» OpenVPN TCP     :** `https://{DOMAIN}:81/tcp.ovpn`
**» OpenVPN UDP     :** `https://{DOMAIN}:81/udp.ovpn`
**━━━━━━━━━━━━━━━━━**
**» Save Link Account:** `https://{DOMAIN}:81/ssh-{user.strip()}.txt`
**» Expired Until:** `{later}`
**»☎️ @HokageLegend**
"""
				await event.respond(msg)

		except asyncio.TimeoutError:
			await event.respond("**Batas waktu habis (120 detik).**\nSilakan ulangi proses.")
		except Exception as e:
			await event.respond(f"**Terjadi Error:**\n`{str(e)}`")

	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("Akses Ditolak", alert=True)

# =================================================================
# 2. DELETE SSH (DENGAN MENGHAPUS LIMIT)
# =================================================================
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		try:
			# --- [PERBAIKAN] Menggunakan loop 'while' untuk validasi sender.id ---
			async with bot.conversation(chat, timeout=120) as user_convo:
				await event.respond("**Username To Be Deleted:**")
				while True:
					user_event = await user_convo.wait_event(events.NewMessage(incoming=True))
					if user_event.sender_id == sender.id:
						user = user_event.raw_text
						break
				
			cmd = f'printf "%s\n" "{user}" | bot-delssh'
			
			try:
				a = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
			except subprocess.CalledProcessError:
				await event.respond(f"**User** `{user}` **Not Found**")
			else:
				# [PENTING] Menghapus juga limit dari file /etc/security/limits.conf
				cmd_dellimit = f'sed -i "/^{user} hard maxlogins/d" /etc/security/limits.conf'
				subprocess.run(cmd_dellimit, shell=True)
				await event.respond(f"**Successfully Deleted** `{user}`")
				
		except asyncio.TimeoutError:
			await event.respond("**Batas waktu habis (120 detik).**\nSilakan ulangi proses.")
		except Exception as e:
			await event.respond(f"**Terjadi Error:**\n`{str(e)}`")
			
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("Akses Ditolak", alert=True)

# =================================================================
# 3. TRIAL SSH (DENGAN LIMIT 1)
# =================================================================
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		try:
			# --- [PERBAIKAN] Menggunakan loop 'while' untuk validasi sender.id ---
			async with bot.conversation(chat, timeout=120) as exp_convo:
				await event.respond("**Choose Expiry Minutes**",buttons=[
					[Button.inline(" 10 Menit ","10"), Button.inline(" 15 Menit ","15")],
					[Button.inline(" 30 Menit ","30"), Button.inline(" 60 Menit ","60")]
				])
				while True:
					exp_event = await exp_convo.wait_event(events.CallbackQuery())
					if exp_event.sender_id == sender.id:
						exp = exp_event.data.decode("ascii")
						try:
							await exp_event.delete()
						except:
							pass
						break

			user = "trialX"+str(random.randint(100,1000))
			pw = "1"
			
			await event.edit("Processing.")
			# ... (animasi loading) ...
			await event.edit("`Wait.. Setting up an Account`")
	
			cmd = f'useradd -e "`date -d "{exp} minutes" +"%Y-%m-%d %H:%M:%S"`" -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user} && tmux new-session -d -s {user} "trial trialssh {user} {exp}" && echo "{user} hard maxlogins 1" >> /etc/security/limits.conf'
	
			try:
				subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
			except subprocess.CalledProcessError as e:
				print(e.output.decode()) # Untuk debugging di server
				await event.respond("**Gagal membuat trial account.**\nCek log server.")
			else:
				msg = f"""
**━━━━━━━━━━━━━━━━━**
 **🟢 SSH  ACCOUNT 🟢**
**━━━━━━━━━━━━━━━━━**
**» Username      :** `{user.strip()}`
**» Password      :** `{pw.strip()}`
**» Max Login/IP   :** `1`
**━━━━━━━━━━━━━━━━━**
**» Host          :** `{DOMAIN}`
**» Host Slowdns  :** `{HOST}`
**» Pub Key       :** `{PUB}`
**» Port OpenSSH  :** `443, 80, 22`
**» Port DNS      :** `443, 53 ,22`
**» Port Dropbear :** `443, 109`
**» Port Dropbear WS :** `443, 109`
**» Port SSH WS     :** `80, 8080, 8081-9999 `
**» Port SSH SSL WS :** `443`
**» Port SSL/TLS    :** `222-1000`
**» Port OVPN WS SSL :** `443`
**» Port OVPN SSL   :** `443`
**» Port OVPN TCP   :** `443, 1194`
**» Port OVPN UDP   :** `2200`
**» Proxy Squid     :** `3128`
**» BadVPN UDP      :** `7100, 7300, 7300`
**━━━━━━━━━━━━━━━━━**
**» Payload WSS     :** `GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━**
**» OpenVPN WS SSL  :** `https://{DOMAIN}:81/ws-ssl.ovpn`
**» OpenVPN SSL     :** `https://{DOMAIN}:81/ssl.ovpn`
**» OpenVPN TCP     :** `https://{DOMAIN}:81/tcp.ovpn`
**» OpenVPN UDP     :** `https://{DOMAIN}:81/udp.ovpn`
**━━━━━━━━━━━━━━━━━**
**» Save Link Account:** `https://{DOMAIN}:81/ssh-{user.strip()}.txt`
**» Expired Until:** `{exp} Minutes`
**»☎️ @HokageLegend**
"""
				await event.respond(msg)
		
		except asyncio.TimeoutError:
			await event.respond("**Batas waktu habis (120 detik).**\nSilakan ulangi proses.")
		except Exception as e:
			await event.respond(f"**Terjadi Error:**\n`{str(e)}`")

	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("Akses Ditolak", alert=True)

# =================================================================
# 4. FUNGSI LAINNYA (SHOW, LOGIN, MENU)
# =================================================================
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
	async def show_ssh_(event):
		try:
			cmd = 'bot-member-ssh'.strip()
			z = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
			await event.respond(f"""
{z}

**Show All SSH User**

""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		except Exception as e:
			await event.respond(f"**Terjadi Error:**\n`{str(e)}`")

	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("Access Denied", alert=True)
		

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		try:
			cmd = 'bot-cek-login-ssh'.strip()
			z = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
			await event.respond(f"""

{z}

**shows logged in users SSH Ovpn**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		except Exception as e:
			await event.respond(f"**Terjadi Error:**\n`{str(e)}`")

	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Access Denied", alert=True)


@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		try:
			# [PERBAIKAN] Mengganti typo 'Button.inlin' menjadi 'Button.inline'
			inline = [
				[Button.inline(" TRIAL SSH ","trial-ssh"), Button.inline(" CREATE SSH ","create-ssh")],
				[Button.inline(" DELETE SSH ","delete-ssh"), Button.inline(" CHECK Login SSH ","login-ssh")],
				[Button.inline(" SHOW All USER SSH ","show-ssh"), Button.inline(" REGIS IP ","regis")],
				[Button.inline("‹ Main Menu ›","menu")]
			]
			try:
				z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
				isp_info = z.get("isp", "N/A")
				country_info = z.get("country", "N/A")
			except requests.RequestException:
				isp_info = "Gagal mendapatkan info ISP"
				country_info = "Gagal mendapatkan info Negara"

			msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
** HOKAGE PREMIUM TUNNELING **
━━━━━━━━━━━━━━━━━━━━━━━ 
━━━━━━━━━━━━━━━━━━━━━━━ 
 **⚠️ MENU SSH & OVPN ⚠️**
━━━━━━━━━━━━━━━━━━━━━━━ 
🟢 **» Service:** `SSH OVPN`
🟢 **» Hostname/IP:** `{DOMAIN}`
🟢 **» ISP:** `{isp_info}`
🟢 **» Country:** `{country_info}`
🇮🇩 **» @HokageLegend****
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
			await event.edit(msg, buttons=inline)
		except Exception as e:
			await event.edit(f"**Terjadi Error:**\n`{str(e)}`")

	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied", alert=True)