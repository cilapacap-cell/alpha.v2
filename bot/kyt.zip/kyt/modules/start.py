from kyt import *
import os

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    # --- BUTTONS ---
    inline = [
        [Button.inline("⚡ PANEL CREATE ACCOUNT ⚡","menu")],
        [Button.url("💬 OFFICIAL CHANNEL","https://t.me/hokagelegend1"),
         Button.url("🛒 ORDER SCRIPT","https://t.me/hokagelegend1")]
    ]
    
    sender = await event.get_sender()
    chat_id = str(sender.id)
    val = valid(chat_id)
    
    if val == "false":
        try:
            await event.answer("❌ Akses Ditolak", alert=True)
        except:
            await event.reply("❌ Akses Ditolak")
    elif val == "true":
        # --- GET SYSTEM INFO ---
        # (Bagian ini sama seperti sebelumnya)
        sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
        vls = subprocess.check_output(vl, shell=True).decode("ascii")
        tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
        trj = subprocess.check_output(tr, shell=True).decode("ascii")
        sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
        ipvps = f" curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
        citsy = f" cat /etc/xray/city"
        city = subprocess.check_output(citsy, shell=True).decode("ascii")

        # --- LOGIC STATUS (Admin/Reseller) ---
        status_user = "👑 ADMIN / OWNER" # Icon Crown untuk Owner
        db_reseller = "/root/reseller_data.txt"
        
        try:
            if os.path.exists(db_reseller):
                with open(db_reseller, "r") as f:
                    data_lines = f.readlines()
                    for line in data_lines:
                        parts = line.strip().split("|")
                        if len(parts) >= 1:
                            if parts[0] == chat_id:
                                status_user = "💼 RESELLER PARTNER" # Icon Tas Kerja untuk Reseller
                                break
        except:
            pass

        # --- TAMPILAN BARU (MODERN STYLE) ---
        # Menggunakan format HTML style (bold/code) agar lebih rapi
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💎 <b>HOKAGE PREMIUM TUNNELING</b> 💎
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👋 <b>Welcome, {sender.first_name}!</b>

<b>🖥️ SERVER INFORMATION</b>
┌──────────────────────────────
│ <b>⚙️ OS System</b>   : <code>{namaos.strip().replace('"','')}</code>
│ <b>📡 Public IP</b>   : <code>{ipsaya.strip()}</code>
│ <b>📍 Location</b>    : <code>{city.strip()}</code>
│ <b>🌐 Domain</b>      : <code>{DOMAIN}</code>
└──────────────────────────────

<b>👤 ACCOUNT INFORMATION</b>
┌──────────────────────────────
│ <b>🆔 Telegram ID</b> : <code>{chat_id}</code>
│ <b>🏷️ Access Role</b> : <code>{status_user}</code>
└──────────────────────────────

<i>🤖 Managed by Alpha Script Auto-Installer</i>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
        # Kirim pesan
        x = await event.edit(msg, buttons=inline, parse_mode='html')
        if not x:
            await event.reply(msg, buttons=inline, parse_mode='html')